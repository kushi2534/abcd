import { useMemo, useState } from 'react';
import { Link, Route, Switch, useLocation } from 'wouter';
import {
  ArrowDown, ArrowRight, ArrowUpRight, Bell, Check, CheckCheck, ChevronDown,
  ChevronRight, CircleHelp, Clock3, Copy, FileText, Filter, Layers3, Menu,
  MessageSquareText, Plus, Quote, RotateCcw, ShieldCheck, Sparkles,
  SquareArrowOutUpRight, Target, X,
} from 'lucide-react';

type Message = { id: number; author: string; initials: string; time: string; text: string; channel: string };
type Finding = { title: string; detail: string; evidence: number[]; state?: string };
const SAMPLE: Message[] = [
  { id: 1, author: 'Maya Chen', initials: 'MC', time: 'Mon 9:04 AM', channel: 'launch-room', text: 'Morning all — let’s use this thread to lock the onboarding refresh before Friday.' },
  { id: 2, author: 'Leo Park', initials: 'LP', time: 'Mon 9:07 AM', channel: 'launch-room', text: 'I pulled the activation numbers from last week. Biggest drop is still between invite and first project.' },
  { id: 3, author: 'Priya Nair', initials: 'PN', time: 'Mon 9:10 AM', channel: 'launch-room', text: 'Agreed. The empty state is doing almost no work for new teams.' },
  { id: 4, author: 'Maya Chen', initials: 'MC', time: 'Mon 9:12 AM', channel: 'launch-room', text: 'Could we make the first project feel less like a blank canvas and more like a guided next step?' },
  { id: 5, author: 'Noah Williams', initials: 'NW', time: 'Mon 9:18 AM', channel: 'launch-room', text: 'I can sketch a short checklist. Would that be enough, or should we prefill a sample project too?' },
  { id: 6, author: 'Priya Nair', initials: 'PN', time: 'Mon 9:23 AM', channel: 'launch-room', text: 'A checklist is safer for v1. Prefill risks feeling fake if it doesn’t match their workflow.' },
  { id: 7, author: 'Leo Park', initials: 'LP', time: 'Mon 9:31 AM', channel: 'launch-room', text: 'I’ll pull the top three activation paths by team size so we can keep the checklist focused.' },
  { id: 8, author: 'Maya Chen', initials: 'MC', time: 'Mon 9:34 AM', channel: 'launch-room', text: 'Thanks Leo. Can you get that to us by Tuesday afternoon? I’ll bring a first copy pass.' },
  { id: 9, author: 'Noah Williams', initials: 'NW', time: 'Mon 9:42 AM', channel: 'launch-room', text: 'One concern: the welcome checklist needs the workspace role from the profile endpoint.' },
  { id: 10, author: 'Priya Nair', initials: 'PN', time: 'Mon 9:46 AM', channel: 'launch-room', text: 'Is that endpoint already returning role for invited users, or only owners?' },
  { id: 11, author: 'Noah Williams', initials: 'NW', time: 'Mon 9:52 AM', channel: 'launch-room', text: 'I’m checking now. The staging response I saw yesterday omitted it for invited users.' },
  { id: 12, author: 'Maya Chen', initials: 'MC', time: 'Mon 10:02 AM', channel: 'launch-room', text: 'Let’s flag that as a blocker until we know. @Eli can you confirm the profile response?' },
  { id: 13, author: 'Eli Brooks', initials: 'EB', time: 'Mon 10:14 AM', channel: 'launch-room', text: 'I can confirm after the schema migration lands. It’s currently in review.' },
  { id: 14, author: 'Leo Park', initials: 'LP', time: 'Mon 11:05 AM', channel: 'launch-room', text: 'Found the same pattern in 62% of small teams: they invite first, then create a project.' },
  { id: 15, author: 'Maya Chen', initials: 'MC', time: 'Mon 11:13 AM', channel: 'launch-room', text: 'That supports checklist first. Let’s not over-design the sample project right now.' },
  { id: 16, author: 'Noah Williams', initials: 'NW', time: 'Mon 1:22 PM', channel: 'launch-room', text: 'First checklist outline is in the doc. Three steps: invite someone, make a project, add a first task.' },
  { id: 17, author: 'Priya Nair', initials: 'PN', time: 'Mon 1:36 PM', channel: 'launch-room', text: 'The third step should probably be “choose what to work on” rather than add a task. Less prescriptive.' },
  { id: 18, author: 'Maya Chen', initials: 'MC', time: 'Mon 2:08 PM', channel: 'launch-room', text: 'I’ll revise the wording and share the copy in the morning. @Noah, can you keep the layout to one screen?' },
  { id: 19, author: 'Noah Williams', initials: 'NW', time: 'Mon 2:12 PM', channel: 'launch-room', text: 'Yep, I’ll keep it compact. Need to confirm role data before I wire the conditional step.' },
  { id: 20, author: 'Eli Brooks', initials: 'EB', time: 'Mon 4:17 PM', channel: 'launch-room', text: 'Schema review is done. Migration is going out tomorrow morning, then I’ll post the response shape here.' },
  { id: 21, author: 'Maya Chen', initials: 'MC', time: 'Tue 9:02 AM', channel: 'launch-room', text: 'Copy v1 is in the doc. “A good place to start” feels warmer than “complete your setup”.' },
  { id: 22, author: 'Priya Nair', initials: 'PN', time: 'Tue 9:15 AM', channel: 'launch-room', text: 'Much better. Could we add an easy skip so returning invitees aren’t forced through the checklist?' },
  { id: 23, author: 'Noah Williams', initials: 'NW', time: 'Tue 9:33 AM', channel: 'launch-room', text: 'Yes, skip is simple. I’m still blocked on role data though; the migration hasn’t hit staging yet.' },
  { id: 24, author: 'Eli Brooks', initials: 'EB', time: 'Tue 10:06 AM', channel: 'launch-room', text: 'Migration is live in staging. Invited members now return role=member; owners return role=owner.' },
  { id: 25, author: 'Noah Williams', initials: 'NW', time: 'Tue 10:19 AM', channel: 'launch-room', text: 'Confirmed, I can see it now. I’ll wire the conditional checklist and send a build for review.' },
  { id: 26, author: 'Maya Chen', initials: 'MC', time: 'Tue 10:27 AM', channel: 'launch-room', text: 'Great. The first review target is still Thursday EOD, then Friday for release if QA is clean.' },
  { id: 27, author: 'Leo Park', initials: 'LP', time: 'Tue 11:41 AM', channel: 'launch-room', text: 'Sharing the activation path chart. Small teams are the clearest case; larger teams split across two routes.' },
  { id: 28, author: 'Priya Nair', initials: 'PN', time: 'Tue 12:03 PM', channel: 'launch-room', text: 'I’d keep v1 one-size-fits-most and learn from the first week. No branching by team size yet.' },
  { id: 29, author: 'Noah Williams', initials: 'NW', time: 'Tue 2:18 PM', channel: 'launch-room', text: 'Build is up on preview. The member path skips the owner-only billing step.' },
  { id: 30, author: 'Maya Chen', initials: 'MC', time: 'Tue 2:26 PM', channel: 'launch-room', text: 'Nice. I promised I’d review the copy by Wednesday lunch — please leave the doc open for comments.' },
  { id: 31, author: 'Eli Brooks', initials: 'EB', time: 'Tue 3:40 PM', channel: 'launch-room', text: 'One caveat: the role field is null for legacy workspaces created before the migration.' },
  { id: 32, author: 'Noah Williams', initials: 'NW', time: 'Tue 3:51 PM', channel: 'launch-room', text: 'That means checklist condition can’t assume a role is always present. I’ll default to the member-safe path.' },
  { id: 33, author: 'Priya Nair', initials: 'PN', time: 'Wed 9:11 AM', channel: 'launch-room', text: 'QA found the skip link is below the fold on smaller laptop screens. Can we move it beside the title?' },
  { id: 34, author: 'Noah Williams', initials: 'NW', time: 'Wed 9:28 AM', channel: 'launch-room', text: 'Yes, I’ll adjust the layout today. That also makes the skip action easier to discover.' },
  { id: 35, author: 'Maya Chen', initials: 'MC', time: 'Wed 10:07 AM', channel: 'launch-room', text: 'Copy review is done — notes are in the doc. I owe the final pass before lunch, and I’ll get it there.' },
  { id: 36, author: 'Leo Park', initials: 'LP', time: 'Wed 10:32 AM', channel: 'launch-room', text: 'Do we still want the Friday release if QA catches more layout issues? I’d rather protect the first-run experience.' },
  { id: 37, author: 'Priya Nair', initials: 'PN', time: 'Wed 10:46 AM', channel: 'launch-room', text: 'Strong agree. A rough first-run flow is harder to recover from than a small date slip.' },
  { id: 38, author: 'Maya Chen', initials: 'MC', time: 'Wed 11:04 AM', channel: 'launch-room', text: 'Decision: move release to Monday. Keep Thursday review, use Friday for QA fixes and a final check.' },
  { id: 39, author: 'Noah Williams', initials: 'NW', time: 'Wed 11:12 AM', channel: 'launch-room', text: 'Understood. I’ll finish the skip placement today and leave Friday for QA fixes.' },
  { id: 40, author: 'Eli Brooks', initials: 'EB', time: 'Wed 11:33 AM', channel: 'launch-room', text: 'I’ll add a null-role case to the integration test suite before Thursday review.' },
  { id: 41, author: 'Maya Chen', initials: 'MC', time: 'Wed 12:02 PM', channel: 'launch-room', text: '@Leo could you post a one-paragraph readout of the small-team data for the launch note?' },
  { id: 42, author: 'Leo Park', initials: 'LP', time: 'Wed 12:18 PM', channel: 'launch-room', text: 'Sure — I can do that by Thursday morning.' },
  { id: 43, author: 'Priya Nair', initials: 'PN', time: 'Wed 1:26 PM', channel: 'launch-room', text: 'Should we cancel the customer walkthrough we pencilled in for Friday, or move it with the release?' },
  { id: 44, author: 'Maya Chen', initials: 'MC', time: 'Wed 1:42 PM', channel: 'launch-room', text: 'Cancel Friday’s walkthrough. We can invite the same group once the Monday release is stable.' },
  { id: 45, author: 'Noah Williams', initials: 'NW', time: 'Wed 2:11 PM', channel: 'launch-room', text: 'Layout change is on preview. The skip link now stays visible at 1280 and 1024 widths.' },
  { id: 46, author: 'Eli Brooks', initials: 'EB', time: 'Wed 2:34 PM', channel: 'launch-room', text: 'Null-role integration test is green. I’ve added the response examples to the doc too.' },
  { id: 47, author: 'Maya Chen', initials: 'MC', time: 'Wed 3:06 PM', channel: 'launch-room', text: 'Final copy pass is in. @Noah please make sure the preview points at this version before review.' },
  { id: 48, author: 'Noah Williams', initials: 'NW', time: 'Wed 3:19 PM', channel: 'launch-room', text: 'Done. Thursday review is ready; Monday release remains the target unless QA finds anything blocking.' },
];

const DEMO_FINDINGS: Record<string, Finding[]> = {
  updates: [
    { title: 'Onboarding checklist is now the v1 direction', detail: 'The team moved away from a prefilled sample project. The checklist stays one-size-fits-most for launch.', evidence: [6, 15, 28] },
    { title: 'Member role data is available in staging', detail: 'The migration landed; legacy workspaces can still return a null role.', evidence: [24, 31] },
  ],
  decisions: [
    { title: 'Release moved from Friday to Monday', detail: 'Thursday review stays. Friday is now reserved for QA fixes and a final check.', evidence: [26, 38], state: 'CONFIRMED · later decision' },
    { title: 'Friday customer walkthrough is cancelled', detail: 'Invite the same group after Monday’s release is stable.', evidence: [43, 44] },
  ],
  mentions: [{ title: 'Maya asked you to post the small-team data readout', detail: 'Requested from Leo by Thursday morning.', evidence: [41, 42] }],
  questions: [{ title: 'What is the null-role fallback for legacy workspaces?', detail: 'No explicit product answer appears in this excerpt. Noah proposes a member-safe path; confirm that is intended.', evidence: [31, 32], state: 'UNCERTAIN · confirm with team' }],
  deadlines: [
    { title: 'Thursday morning · small-team data readout', detail: 'Leo said he can post it by then.', evidence: [41, 42] },
    { title: 'Thursday EOD · review', detail: 'Still the review target after the release date moved.', evidence: [26, 38] },
    { title: 'Monday · release target', detail: 'Replaces the earlier Friday target; contingent on QA.', evidence: [26, 38, 48], state: 'CONFIRMED · supersedes Friday' },
  ],
  next: [
    { title: 'Publish the data readout', detail: 'Leo · Thursday morning', evidence: [41, 42] },
    { title: 'Finish skip-link layout and prepare Thursday review', detail: 'Noah · in progress', evidence: [33, 45, 47] },
    { title: 'Add null-role integration test', detail: 'Eli · reported green; check it is included in review build.', evidence: [40, 46] },
  ],
};
const commitments = [
  { id: 'c1', task: 'Post the small-team activation readout', who: 'Leo Park', when: 'Thursday morning', evidence: [41, 42], urgency: 'TODAY' },
  { id: 'c2', task: 'Make the final copy pass', who: 'Maya Chen', when: 'Before lunch · Wednesday', evidence: [35], urgency: 'OVERDUE' },
  { id: 'c3', task: 'Keep checklist to one screen; move skip link', who: 'Noah Williams', when: 'Before Thursday review', evidence: [18, 33, 34], urgency: 'IN PROGRESS' },
  { id: 'c4', task: 'Add the null-role case to integration tests', who: 'Eli Brooks', when: 'Before Thursday review', evidence: [40, 46], urgency: 'DONE' },
];
const promisePattern = /\b(i['’]?ll|i will|i can|i owe|we['’]?ll|we will|we can|promise|committed to|taking this)\b/i;
const deadlinePattern = /\b(today|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday|by\s+\w+|due\s+\w+|deadline|eod|eow|next week|\d{1,2}[/-]\d{1,2})\b/i;
const updatePattern = /\b(blocked|blocker|shipped|released|fixed|finished|complete|completed|updated|changed|live|merged|resolved|in progress)\b/i;
const decisionPattern = /\b(decision|decided|agreed|we chose|we choose|let['’]?s|going with|will use)\b/i;
const actionPattern = /\b(i['’]?ll|i will|i can|please|can you|could you|need to|should we|follow up|take this|own this)\b/i;

function candidateFinding(title: string, line: { id: number; line: string }): Finding {
  return {
    title,
    detail: line.line,
    evidence: [line.id],
    state: 'CANDIDATE · local wording',
  };
}

function Logo({ light = false }: { light?: boolean }) {
  return <span className={`brand ${light ? 'brand-light' : ''}`}><span className="brand-mark"><Layers3 size={16} strokeWidth={2.2} /></span><span>what did I miss<span className="brand-period">?</span></span></span>;
}

function Header() {
  const [, setLocation] = useLocation();
  const [menu, setMenu] = useState(false);
  return <header className="site-nav"><Link href="/" className="brand-link"><Logo /></Link>
    <nav className={menu ? 'nav-links nav-open' : 'nav-links'} aria-label="Main navigation">
      <a href="/#how-it-works" onClick={() => setMenu(false)}>How it works</a><a href="/#principles" onClick={() => setMenu(false)}>Why it’s different</a>
      <button className="nav-quiet" onClick={() => { setLocation('/studio'); setMenu(false); }}>Open the studio <ArrowUpRight size={14} /></button>
    </nav>
    <button className="mobile-menu" aria-label="Toggle menu" onClick={() => setMenu(!menu)}>{menu ? <X /> : <Menu />}</button>
    <button className="nav-cta" onClick={() => setLocation('/studio')}>Try Live Demo <ArrowRight size={15} /></button>
  </header>;
}

function Landing() {
  const [, setLocation] = useLocation();
  return <div className="landing">
    <Header />
    <main>
      <section className="hero-section">
        <div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" />
        <div className="hero-copy">
          <div className="eyebrow"><span className="live-dot" /> A calmer way back into the conversation</div>
          <h1 className="hero-headline">Hundreds of unread<br />messages. <em>Zero time<br />to catch up.</em></h1>
          <p className="hero-lede"><strong>Skip the noise. Catch what matters. Know your next move.</strong> See what changed, what you owe, and why it matters — with the receipts attached.</p>
          <div className="hero-actions"><button className="button-primary" onClick={() => setLocation('/studio')}>Analyze My Chats <ArrowRight size={16} /></button><button className="text-link" onClick={() => setLocation('/studio')}>Try Live Demo <ArrowUpRight size={14} /></button></div>
          <div className="hero-footnote"><ShieldCheck size={15} /> Runs in your browser. Your conversation stays yours.</div>
        </div>
        <div className="hero-visual" aria-label="Catch-up summary preview">
          <div className="visual-top"><span className="visual-window"><i /><i /><i /></span><span>launch-room / since Monday</span><span className="sample-chip">DEMO DATA</span></div>
          <div className="visual-body">
            <div className="visual-kicker"><Sparkles size={13} /> YOUR CATCH-UP</div>
            <h3>One date moved.<br />Three things still need you.</h3>
            <div className="visual-line"><span className="line-icon teal"><Check size={13} /></span><div><b>Release is now Monday</b><small>Friday replaced · Thursday review stays</small></div><span className="evidence-mini">2 msgs</span></div>
            <div className="visual-line"><span className="line-icon amber"><Clock3 size={13} /></span><div><b>Data readout requested</b><small>Leo · Thursday morning</small></div><span className="evidence-mini">#41</span></div>
            <div className="visual-line"><span className="line-icon lilac"><CircleHelp size={13} /></span><div><b>Legacy role fallback</b><small>Suggested, not confirmed</small></div><span className="evidence-mini">check</span></div>
            <div className="visual-bottom"><span><span className="tiny-dot" /> Evidence linked to source messages</span><button onClick={() => setLocation('/studio')}>Explore demo <ArrowRight size={13} /></button></div>
          </div>
        </div>
        <div className="hero-index"><span>01</span> / A LITTLE LESS CATCHING UP</div>
      </section>
      <section className="proof-strip"><span>BUILT FOR THE MOMENT YOU RETURN</span><div><b>Not another wall of summary.</b><i /><b>A clear next move.</b><i /><b>Evidence, not guesswork.</b></div></section>
      <section className="story-section" id="how-it-works">
        <div className="section-heading"><span className="eyebrow">THE SIGNAL, NOT THE SCROLL</span><h2>Make the backlog<br /><em>make sense.</em></h2><p>Paste a busy thread. Get a human-readable map of where things stand, without pretending the fuzzy bits are facts.</p></div>
        <div className="story-grid">
          <article className="story-card"><div className="story-count">01 / WHAT CHANGED</div><div className="story-symbol"><MessageSquareText size={21} /></div><h3>Context, in order.</h3><p>See the update that matters, what it replaced, and the path the team took to get there.</p><div className="mini-thread"><span>FRIDAY RELEASE</span><span className="strike">superseded</span><span className="current">MONDAY RELEASE <Check size={12} /></span></div></article>
          <article className="story-card story-card-offset"><div className="story-count">02 / WHAT YOU OWE</div><div className="story-symbol purple"><Target size={21} /></div><h3>Your promises, surfaced.</h3><p>Requests and commitments rise above the noise. Mark what’s done; filter what’s still open.</p><div className="promise-chip"><span className="promise-square"><Check size={12} /></span><span>Send the readout</span><small>THU AM</small></div></article>
          <article className="story-card"><div className="story-count">03 / WHY IT MATTERS</div><div className="story-symbol amber"><Quote size={21} /></div><h3>Every point has a trail.</h3><p>Jump from a finding back to the exact message. Unclear signals stay clearly uncertain.</p><div className="quote-proof"><span>“Decision: move release to Monday.”</span><small>MAYA CHEN · MESSAGE 38 <ArrowUpRight size={11} /></small></div></article>
        </div>
      </section>
      <section className="manifesto" id="principles"><div className="manifesto-mark"><Layers3 size={25} /></div><div><span className="eyebrow">A BETTER KIND OF CATCH-UP</span><h2>Useful is more honest<br />than <em>impressive.</em></h2></div><div className="manifesto-side"><p>What Did I Miss? works locally. It does not need a login, an API key, or a promise that a machine understands everything.</p><p>Demo findings are labelled. Pasted text is treated with care: source-backed where possible, uncertain where not.</p><button className="inline-cta" onClick={() => setLocation('/studio')}>Try the workspace <ArrowRight size={15} /></button></div></section>
      <section className="last-call"><div className="last-call-top"><span>START WITH THE THREAD YOU’RE AVOIDING.</span><span>NO ACCOUNT. NO API KEY.</span></div><h2>Come back to the<br /><em>conversation.</em></h2><button className="button-primary" onClick={() => setLocation('/studio')}>Open Catch-Up Studio <ArrowRight size={16} /></button><div className="last-call-footer"><Logo light /><span>Calm context, right where you need it.</span></div></section>
    </main>
  </div>;
}

function Evidence({ ids, onSource }: { ids: number[]; onSource: (id: number) => void }) {
  return <div className="evidence-list"><span className="evidence-label">EVIDENCE</span>{ids.map(id => <button key={id} onClick={() => onSource(id)} className="evidence-link">#{id}</button>)}</div>;
}
function FindingCard({ finding, onSource }: { finding: Finding; onSource: (id: number) => void }) {
  return <article className="finding-card"><div className="finding-top"><div className="finding-title">{finding.title}</div>{finding.state && <span className={finding.state.includes('UNCERTAIN') ? 'certainty uncertain' : 'certainty'}>{finding.state}</span>}</div><p>{finding.detail}</p><Evidence ids={finding.evidence} onSource={onSource} /></article>;
}

function Studio() {
  const [mode, setMode] = useState('Balanced');
  const [tab, setTab] = useState('Executive summary');
  const [text, setText] = useState('');
  const [isDemo, setIsDemo] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [sourceId, setSourceId] = useState<number | null>(null);
  const [done, setDone] = useState<string[]>(['c4']);
  const [pendingOnly, setPendingOnly] = useState(false);
  const [fiveMin, setFiveMin] = useState(false);
  const [tone, setTone] = useState('Professional');
  const [reply, setReply] = useState('Thanks for the update — I’ve got the Monday release target and Thursday review. I’ll share the activation readout by Thursday morning.');
  const [copied, setCopied] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const parsedLines = useMemo(() => text.split(/\n/).map((line, i) => ({ id: i + 1, line: line.trim() })).filter(item => item.line), [text]);
  const localSignals = useMemo(() => {
    const signals: Record<'updates' | 'decisions' | 'mentions' | 'questions' | 'deadlines' | 'next', Finding[]> = {
      updates: [], decisions: [], mentions: [], questions: [], deadlines: [], next: [],
    };
    parsedLines.forEach(line => {
      if (updatePattern.test(line.line)) signals.updates.push(candidateFinding('Possible status update', line));
      if (decisionPattern.test(line.line)) signals.decisions.push(candidateFinding('Possible decision language', line));
      if (/@[\w.-]+/.test(line.line)) signals.mentions.push(candidateFinding('Direct @mention found', line));
      if (/\?\s*$/.test(line.line)) signals.questions.push(candidateFinding('Question found', line));
      if (deadlinePattern.test(line.line)) signals.deadlines.push(candidateFinding('Possible date or deadline', line));
      if (actionPattern.test(line.line)) signals.next.push(candidateFinding('Possible request or commitment', line));
    });
    return signals;
  }, [parsedLines]);
  const localCommitmentLines = useMemo(
    () => parsedLines.filter(line => promisePattern.test(line.line)),
    [parsedLines],
  );
  const localLine = sourceId && !isDemo ? parsedLines.find(line => line.id === sourceId)?.line : null;
  const activeSource = isDemo ? SAMPLE.find(message => message.id === sourceId) : null;
  const changeTone = (nextTone: string) => {
    setTone(nextTone);
    if (!isDemo) {
      if (nextTone === 'Friendly') setReply('Thanks for sending this over — I’ve read through it and will follow up on anything relevant to me.');
      else if (nextTone === 'Concise') setReply('Thanks for the context. I’ll follow up on relevant items.');
      else setReply('Thanks for sharing this thread. I’ve reviewed the messages and will follow up on the points relevant to me.');
    } else if (nextTone === 'Friendly') setReply('Thanks for looping me in! I’m caught up now — I’ll get that activation readout over by Thursday morning, and I’ve noted the Monday launch plan.');
    else if (nextTone === 'Concise') setReply('Got it: Monday release, Thursday review. I’ll send the readout Thursday morning.');
    else setReply('Thanks for the update — I’ve got the Monday release target and Thursday review. I’ll share the activation readout by Thursday morning.');
  };
  const analyze = () => {
    setError('');
    if (!text.trim()) { setError('Paste a conversation first. Even a few lines is enough to start.'); return; }
    setBusy(true);
    window.setTimeout(() => { setBusy(false); setIsDemo(false); setSourceId(null); setTab('Executive summary'); setTone('Professional'); setReply('Thanks for sharing this thread. I’ve reviewed the messages and will follow up on the points relevant to me.'); }, 620);
  };
  const visibleCommitments = commitments.filter(item => !pendingOnly || !done.includes(item.id));
  const tabs = ['Executive summary', 'Updates', 'Decisions', 'Mentions', 'Open questions', 'Deadlines', 'Next actions'];
  const handleCopy = async () => {
    try { await navigator.clipboard.writeText(reply); setCopied(true); window.setTimeout(() => setCopied(false), 1800); }
    catch { setError('Clipboard access is unavailable. Select and copy the reply manually.'); }
  };
  const summaryText = mode === 'Quick'
    ? 'The v1 checklist direction is set. Friday release moved to Monday; Thursday review stays. Leo owes a data readout, and the legacy-role fallback still needs confirmation.'
    : mode === 'Detailed'
      ? 'The team chose a one-size-fits-most onboarding checklist over a prefilled sample project. Profile role data is live in staging, but legacy workspaces may still return null; Noah proposes the member-safe path, which is not explicitly confirmed. The original Friday release target was replaced by Monday. Thursday review remains, with Friday held for QA fixes. Leo accepted a Thursday-morning request for a small-team activation readout.'
      : 'The onboarding checklist is the v1 direction. Role data is live, but legacy workspaces can still return null. The release moved from Friday to Monday; Thursday review remains. A data readout is requested, while the legacy-role fallback still needs confirmation.';
  const navItems = ['Catch-up overview', 'Commitment radar', 'Since you were away', 'Five-minute mode', 'Smart replies'];
  const [activeNav, setActiveNav] = useState(navItems[0]);
  const localFindingsForTab = useMemo(() => {
    if (tab === 'Executive summary') {
      const seen = new Set<number>();
      return Object.values(localSignals).flat().filter(finding => {
        const id = finding.evidence[0];
        if (seen.has(id)) return false;
        seen.add(id);
        return true;
      });
    }
    const category = tab === 'Updates' ? 'updates'
      : tab === 'Decisions' ? 'decisions'
        : tab === 'Mentions' ? 'mentions'
          : tab === 'Open questions' ? 'questions'
            : tab === 'Deadlines' ? 'deadlines' : 'next';
    return localSignals[category];
  }, [localSignals, tab]);
  const localAttentionGroups = useMemo(() => [
    { label: 'ACT NOW', tint: 'act', items: localSignals.next.filter(item => /today|asap|urgent|blocked|overdue/i.test(item.detail)).map(item => ({ ...item, reason: 'Contains an urgency or blocker phrase; verify the priority in context.' })) },
    { label: 'SCHEDULE IT', tint: 'schedule', items: localSignals.deadlines.map(item => ({ ...item, reason: 'A date or timing phrase appears in the source; confirm what it applies to.' })) },
    { label: 'FOLLOW UP', tint: 'follow', items: [...localSignals.questions, ...localSignals.mentions].map(item => ({ ...item, reason: 'A question or direct mention may need a response; check the surrounding messages.' })) },
    { label: 'INFORMATIONAL', tint: 'info', items: [...localSignals.updates, ...localSignals.decisions].map(item => ({ ...item, reason: 'Status or decision wording was found, but its meaning is not verified.' })) },
  ], [localSignals]);
  const jumpTo = (nav: string) => {
    setActiveNav(nav);
    const target = nav === navItems[0] ? 'overview' : nav === navItems[1] ? 'commitments' : nav === navItems[2] ? 'comparison' : nav === navItems[3] ? 'attention' : 'replies';
    document.getElementById(target)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    setMobileNav(false);
    if (nav === navItems[3]) setFiveMin(true);
  };
  const visibleLocalCommitments = localCommitmentLines.filter(item => !pendingOnly || !done.includes(`local-${item.id}`));
  return <div className="studio-shell">
    <aside className={mobileNav ? 'studio-sidebar sidebar-open' : 'studio-sidebar'}>
      <Link href="/" className="side-brand"><Logo /></Link>
      <div className="workspace-label">WORKSPACE</div>
      <div className="space-select"><span className="space-icon">L</span><span><b>Launch team</b><small>Local workspace</small></span><ChevronDown size={14} /></div>
      <div className="side-label">YOUR WORK</div>
      <button className={`side-link ${activeNav === navItems[0] ? 'selected' : ''}`} onClick={() => jumpTo(navItems[0])}><Layers3 size={16} /> Catch-up overview</button>
      <button className={`side-link ${activeNav === navItems[1] ? 'selected' : ''}`} onClick={() => jumpTo(navItems[1])}><Target size={16} /> Commitment radar <span className="side-count">4</span></button>
      <button className={`side-link ${activeNav === navItems[2] ? 'selected' : ''}`} onClick={() => jumpTo(navItems[2])}><RotateCcw size={16} /> Since you were away</button>
      <div className="side-label side-label-spaced">TOOLS</div>
      <button className={`side-link ${activeNav === navItems[3] ? 'selected' : ''}`} onClick={() => jumpTo(navItems[3])}><Clock3 size={16} /> Five-minute mode</button>
      <button className={`side-link ${activeNav === navItems[4] ? 'selected' : ''}`} onClick={() => jumpTo(navItems[4])}><MessageSquareText size={16} /> Smart replies</button>
      <div className="sidebar-bottom"><div className="privacy-card"><ShieldCheck size={15} /><div><b>Private by design</b><p>Analysis happens in this browser. Nothing is uploaded.</p></div></div><div className="profile-row"><span className="profile-avatar">Y</span><span><b>Your workspace</b><small>Local session</small></span><button aria-label="Workspace settings" title="Workspace settings" onClick={() => setError('Settings are local to this browser session. No account is connected.')}><ChevronDown size={14} /></button></div></div>
    </aside>
    {mobileNav && <button className="mobile-scrim" aria-label="Close navigation" onClick={() => setMobileNav(false)} />}
    <main className="studio-main">
      <header className="studio-topbar"><button className="mobile-menu studio-menu" aria-label="Open navigation" onClick={() => setMobileNav(true)}><Menu /></button><div className="breadcrumbs"><span>Launch team</span><ChevronRight size={13} /><b>Catch-up studio</b></div><div className="topbar-actions"><span className="local-tag"><span className="tiny-dot" /> LOCAL ONLY</span><button aria-label="Help" title="How it works" onClick={() => setError('This studio uses a fictional demo thread or local, heuristic parsing of the text you paste. It never contacts an AI service.')} className="icon-button"><CircleHelp size={17} /></button><button aria-label="Notifications" title="Notifications" className="icon-button" onClick={() => setError('You are all caught up. No notifications in this local demo.')}><Bell size={16} /></button></div></header>
      <div className="studio-content">
        <div className="studio-title-row"><div><div className="studio-eyebrow"><span className="live-dot" /> YOUR CONVERSATION BRIEF</div><h1>Catch-up studio</h1><p>Make sense of the thread. Then get back to your day.</p></div><button className="button-secondary" onClick={() => { setIsDemo(true); setText(''); setError(''); setTab('Executive summary'); setSourceId(null); }}><RotateCcw size={14} /> Load demo thread</button></div>
        <section className="input-panel">
          <div className="input-panel-head"><div><span className="input-step">01</span><div><b>Bring in the conversation</b><small>Paste messages here, or explore the sample thread.</small></div></div><span className="secure-note"><ShieldCheck size={14} /> stays on this device</span></div>
          <textarea aria-label="Paste conversation text" data-testid="input-conversation" value={text} onChange={e => { setText(e.target.value); if (isDemo) { setIsDemo(false); setTone('Professional'); setReply('Thanks for sharing this thread. I’ve reviewed the messages and will follow up on the points relevant to me.'); } setError(''); }} placeholder="Paste chat messages, meeting notes, or a conversation export here…" />
          <div className="input-actions"><span>{text ? `${parsedLines.length} non-empty lines · local heuristic mode` : 'No file upload needed'}</span><div className="input-action-right"><button className="button-quiet" onClick={() => { setText(''); setError(''); setIsDemo(true); }}>Clear</button><button className="button-primary analyze-button" onClick={analyze} disabled={busy}>{busy ? <><span className="button-pulse" /> Reading thread…</> : <>Analyze conversation <ArrowRight size={15} /></>}</button></div></div>
          {error && <div className="inline-error" role="alert"><CircleHelp size={15} /> {error}<button aria-label="Dismiss" onClick={() => setError('')}><X size={14} /></button></div>}
          {busy && <div className="loading-skeleton" aria-label="Analyzing conversation"><span /><span /><span /></div>}
        </section>
        {isDemo ? <div className="demo-disclaimer"><Sparkles size={14} /><span><b>DEMO DATA</b> — fictional sample thread with evidence links. Findings below are illustrative, not from a real team.</span><button onClick={() => setText(SAMPLE.map(m => `${m.time} · ${m.author}: ${m.text}`).join('\n'))}>Copy sample into editor <ArrowDown size={13} /></button></div> :
          <div className="demo-disclaimer local-disclaimer"><ShieldCheck size={14} /><span><b>LOCAL HEURISTIC MODE</b> — pasted lines are not interpreted as verified facts. No citations are invented; findings appear only when exact source text can be shown.</span><button onClick={() => { setText(''); setIsDemo(true); }}>Return to demo <RotateCcw size={13} /></button></div>}

        <section className="results-section" id="overview">
          <div className="results-heading"><div><span className="section-index">02 / THE BRIEF</span><h2>Here’s the shape of it.</h2></div><div className="mode-switch" role="group" aria-label="Summary detail mode">{['Quick', 'Balanced', 'Detailed'].map(item => <button key={item} onClick={() => setMode(item)} className={mode === item ? 'mode-active' : ''}>{item}</button>)}</div></div>
          {isDemo ? <div className="summary-banner"><div className="summary-icon"><Sparkles size={17} /></div><div><span className="summary-label">THE SHORT VERSION <span className="demo-mini">DEMO</span></span><p>{summaryText}</p><div className="summary-foot"><span>48 messages</span><i /> <span>Mon 9:04 — Wed 3:19</span><i /> <span>{mode.toLowerCase()} view</span></div></div></div> :
            <div className="summary-banner uncertain-banner"><div className="summary-icon"><CircleHelp size={17} /></div><div><span className="summary-label">LOCAL PARSE · CANDIDATE SIGNALS</span><p>Possible updates, decisions, mentions, questions, dates, and actions are matched from exact wording below. They are not verified facts; check every source line before acting.</p><div className="summary-foot"><span>{parsedLines.length} lines</span><i /> <span>No external analysis</span></div></div></div>}
          <div className="tab-row" role="tablist" aria-label="Catch-up sections">{tabs.map((item, i) => <button role="tab" aria-selected={tab === item} key={item} onClick={() => setTab(item)} className={tab === item ? 'tab-active' : ''}>{item}{i === 4 && <span className="tab-dot" />}</button>)}</div>
          <div className="findings-area">
            {isDemo ? (tab === 'Executive summary' ? <div className="executive-grid"><div className="executive-main"><div className="subsection-title"><h3>What matters most</h3><span>3 THREAD SIGNALS</span></div>{[DEMO_FINDINGS.updates[0], DEMO_FINDINGS.decisions[0], DEMO_FINDINGS.mentions[0]].map((finding, i) => <FindingCard key={i} finding={finding} onSource={setSourceId} />)}</div><aside className="side-summary"><div className="subsection-title"><h3>In a glance</h3><span>DEMO</span></div><div className="glance-row"><span className="glance-icon teal"><CheckCheck size={15} /></span><div><b>2 confirmed decisions</b><small>One replaced an earlier date</small></div></div><div className="glance-row"><span className="glance-icon purple"><Target size={15} /></span><div><b>3 things to follow up</b><small>Including one request to you</small></div></div><div className="glance-row"><span className="glance-icon amber"><CircleHelp size={15} /></span><div><b>1 unresolved question</b><small>Fallback behavior needs a check</small></div></div><button className="see-all" onClick={() => setTab('Next actions')}>See next actions <ArrowRight size={14} /></button></aside></div> :
              <div className="findings-list">{(tab === 'Updates' ? DEMO_FINDINGS.updates : tab === 'Decisions' ? DEMO_FINDINGS.decisions : tab === 'Mentions' ? DEMO_FINDINGS.mentions : tab === 'Open questions' ? DEMO_FINDINGS.questions : tab === 'Deadlines' ? DEMO_FINDINGS.deadlines : DEMO_FINDINGS.next).map((finding, i) => <FindingCard key={i} finding={finding} onSource={setSourceId} />)}</div>) :
               <div className="local-caution"><div className="caution-head"><CircleHelp size={17} /><b>Candidate wording only—not verified conclusions.</b></div><p>These local keyword matches keep the original line attached. They do not determine who owns a task, whether a decision is final, or what a date applies to.</p>{localFindingsForTab.slice(0, mode === 'Quick' ? 3 : mode === 'Balanced' ? 6 : 10).map((finding, i) => <FindingCard key={`${finding.evidence[0]}-${i}`} finding={finding} onSource={setSourceId} />)}{parsedLines.length === 0 && <div className="empty-state"><FileText size={22} /><b>Your brief is waiting.</b><span>Paste text above and choose Analyze conversation.</span></div>}{parsedLines.length > 0 && localFindingsForTab.length === 0 && <div className="empty-state"><CircleHelp size={22} /><b>No matching wording in this section.</b><span>Try another section or review the source lines manually.</span></div>}</div>}
          </div>
        </section>

        <section className="commitments-section" id="commitments">
          <div className="section-heading-inline"><div><span className="section-index">03 / YOUR OPEN LOOPS</span><h2>Commitment radar</h2><p>Promises made in the thread, not a task list someone invented.</p></div><label className="filter-toggle"><input type="checkbox" checked={pendingOnly} onChange={e => setPendingOnly(e.target.checked)} /><span className="fake-check"><Check size={11} /></span>Pending only <Filter size={14} /></label></div>
          {isDemo ? <><div className="promise-callout"><span className="promise-icon"><Target size={17} /></span><div><b>Promises You Might Forget</b><p>Maya explicitly said she owed a final copy pass before lunch. The excerpt does not confirm completion—check whether the doc received it.</p></div><button onClick={() => setSourceId(35)}>View evidence <ChevronRight size={14} /></button></div><div className="commitment-list">{visibleCommitments.length ? visibleCommitments.map(item => <div className={`commitment-row ${done.includes(item.id) ? 'commitment-done' : ''}`} key={item.id}><button className={`check-button ${done.includes(item.id) ? 'checked' : ''}`} aria-label={done.includes(item.id) ? `Mark ${item.task} pending` : `Mark ${item.task} complete`} onClick={() => setDone(done.includes(item.id) ? done.filter(id => id !== item.id) : [...done, item.id])}>{done.includes(item.id) && <Check size={14} />}</button><div className="commitment-task"><b>{item.task}</b><span>{item.who} <i /> {item.when}</span></div><span className={`urgency ${item.urgency === 'OVERDUE' ? 'urgent' : item.urgency === 'DONE' ? 'complete' : ''}`}>{item.urgency}</span><Evidence ids={item.evidence} onSource={setSourceId} /></div>) : <div className="empty-state compact"><CheckCheck size={20} /><b>Everything is marked complete.</b><span>Turn off “Pending only” to see completed commitments.</span></div>}</div></> :
            <><div className="promise-callout"><span className="promise-icon"><Target size={17} /></span><div><b>Promises You Might Forget</b><p>Possible promise wording is shown verbatim. Owner, intent, and completion are not inferred from pasted text.</p></div></div><div className="commitment-list">{visibleLocalCommitments.length ? visibleLocalCommitments.map(line => { const id = `local-${line.id}`; const isDone = done.includes(id); return <div className={`commitment-row ${isDone ? 'commitment-done' : ''}`} key={id}><button className={`check-button ${isDone ? 'checked' : ''}`} aria-label={isDone ? 'Mark candidate commitment pending' : 'Mark candidate commitment complete'} onClick={() => setDone(isDone ? done.filter(item => item !== id) : [...done, id])}>{isDone && <Check size={14} />}</button><div className="commitment-task"><b>{line.line}</b><span>Owner not inferred <i /> Check source for a deadline</span></div><span className="urgency">POSSIBLE</span><Evidence ids={[line.id]} onSource={setSourceId} /></div>; }) : <div className="empty-state compact"><CircleHelp size={20} /><b>{localCommitmentLines.length ? 'All candidate promises are marked complete.' : 'No promise wording detected.'}</b><span>Local matching looks for phrases such as “I’ll” or “I owe”; it can miss or misread commitments.</span></div>}</div></>}
        </section>

        <section className="comparison-section" id="comparison">
          <div className="section-heading-inline"><div><span className="section-index">04 / THE DELTA</span><h2>Since you were away</h2><p>The first version of the plan, and what the thread says now.</p></div><span className="delta-period"><Clock3 size={14} /> MON → WED</span></div>
          {isDemo ? <div className="comparison-list">
            <article className="change-card"><div className="change-type"><span className="change-arrow"><ArrowDown size={15} /></span><span>DEADLINE MOVED</span></div><div className="change-content"><b>Release target</b><div className="before-after"><div><small>ORIGINAL · TUE 10:27</small><span className="old-value">Friday</span></div><ArrowRight size={17} /><div><small>LATEST · WED 11:04</small><span className="new-value">Monday</span></div></div><p>Thursday review remains; Friday is now for QA fixes.</p></div><Evidence ids={[26, 38]} onSource={setSourceId} /></article>
            <article className="change-card"><div className="change-type"><span className="change-arrow purple"><RotateCcw size={15} /></span><span>PLAN REPLACED</span></div><div className="change-content"><b>Release approach</b><div className="before-after"><div><small>EARLIER · TUE</small><span className="old-value">Friday release if QA is clean</span></div><ArrowRight size={17} /><div><small>DECISION · WED</small><span className="new-value">Monday, after Friday QA</span></div></div><p>Later decision explicitly supersedes the earlier target.</p></div><Evidence ids={[26, 36, 38]} onSource={setSourceId} /></article>
            <article className="change-card"><div className="change-type"><span className="change-arrow amber"><X size={15} /></span><span>PLAN CANCELLED</span></div><div className="change-content"><b>Customer walkthrough</b><div className="before-after"><div><small>ORIGINAL · WED 1:26</small><span className="old-value">Friday walkthrough pencilled in</span></div><ArrowRight size={17} /><div><small>LATEST · WED 1:42</small><span className="new-value">Cancelled; re-invite after release</span></div></div><p>Do not move the current invite; a new one is planned later.</p></div><Evidence ids={[43, 44]} onSource={setSourceId} /></article>
            <article className="change-card"><div className="change-type"><span className="change-arrow teal"><Plus size={15} /></span><span>NEW ASSIGNMENT</span></div><div className="change-content"><b>Small-team data readout</b><div className="before-after"><div><small>BEFORE</small><span className="old-value muted-value">No owner in thread</span></div><ArrowRight size={17} /><div><small>NEW · WED 12:02</small><span className="new-value">Leo · Thursday morning</span></div></div><p>Direct request followed by an explicit acceptance.</p></div><Evidence ids={[41, 42]} onSource={setSourceId} /></article>
            <article className="change-card"><div className="change-type"><span className="change-arrow amber"><CircleHelp size={15} /></span><span>STILL UNRESOLVED</span></div><div className="change-content"><b>Legacy workspace role fallback</b><div className="before-after"><div><small>BLOCKER · TUE 3:40</small><span className="old-value">Role can be null</span></div><ArrowRight size={17} /><div><small>PROPOSAL · TUE 3:51</small><span className="new-value">Member-safe path suggested</span></div></div><p>Implementation is described; product intent was not explicitly confirmed.</p></div><span className="uncertain-pill">UNCERTAIN</span></article>
          </div> : <div className="local-empty"><CircleHelp size={18} /><div><b>No verified changes to compare.</b><p>Local parsing does not infer that later lines replace earlier ones. Compare the exact source lines above.</p></div></div>}
        </section>

        <section className="attention-section" id="attention">
          <div className="section-heading-inline"><div><span className="section-index">05 / WHAT TO DO NEXT</span><h2>Attention, in order.</h2><p>A short, reasoned path back into the work.</p></div><button className={`five-toggle ${fiveMin ? 'five-on' : ''}`} onClick={() => setFiveMin(!fiveMin)}><span className="five-icon"><Clock3 size={14} /></span>{fiveMin ? 'Five-minute mode on' : 'Start five-minute mode'}<ArrowRight size={13} /></button></div>
          {isDemo ? <div className="attention-grid">{[
            { label: 'ACT NOW', tint: 'act', items: [{ title: 'Confirm Maya’s final copy pass is in the doc', reason: 'She said she owed it before lunch; no explicit completion message follows.', evidence: [35] }] },
            { label: 'SCHEDULE IT', tint: 'schedule', items: [{ title: 'Review the launch build Thursday', reason: 'Review date stayed in place after Monday release decision.', evidence: [26, 38] }] },
            { label: 'FOLLOW UP', tint: 'follow', items: [{ title: 'Check null-role fallback is the intended behavior', reason: 'A safe-path implementation is described, but not confirmed as product behavior.', evidence: [31, 32] }] },
            { label: 'INFORMATIONAL', tint: 'info', items: [{ title: 'Friday walkthrough has been cancelled', reason: 'The team will invite the same group after release is stable.', evidence: [43, 44] }] },
          ].map(group => <div className={`attention-group ${group.tint}`} key={group.label}><div className="attention-label"><span />{group.label}</div>{group.items.map((item, i) => <div className="attention-item" key={i}><b>{item.title}</b><p>{item.reason}</p><Evidence ids={item.evidence} onSource={setSourceId} /></div>)}</div>)}</div> :
          <div className="attention-grid">{localAttentionGroups.map(group => <div className={`attention-group ${group.tint}`} key={group.label}><div className="attention-label"><span />{group.label}</div>{group.items.length ? group.items.slice(0, mode === 'Quick' ? 2 : mode === 'Balanced' ? 4 : 8).map((item, i) => <div className="attention-item" key={`${item.evidence[0]}-${i}`}><b>{item.title}</b><p>{item.reason}</p><Evidence ids={item.evidence} onSource={setSourceId} /></div>) : <p className="attention-empty">No wording matched this group.</p>}</div>)}</div>}
          {fiveMin && <div className="five-panel"><div className="five-panel-head"><div className="five-mark"><Clock3 size={16} /></div><div><b>Your five-minute re-entry</b><span>Three things, in this order. Start with the concrete ask.</span></div><button aria-label="Close five-minute mode" onClick={() => setFiveMin(false)}><X size={15} /></button></div><div className="five-steps">{(isDemo ? ['Check the final copy pass in the doc', 'Put Thursday review on your calendar', 'Ask about the legacy-role fallback'] : ['Review the source lines you pasted', 'Identify any explicit asks', 'Confirm uncertain details with the team']).map((step, index) => <div key={index}><span>{String(index + 1).padStart(2, '0')}</span><b>{step}</b>{isDemo && <button onClick={() => setSourceId([35, 38, 32][index])}>Evidence <ArrowUpRight size={12} /></button>}</div>)}</div></div>}
        </section>

        <section className="reply-section" id="replies">
          <div className="section-heading-inline"><div><span className="section-index">06 / PICK UP THE THREAD</span><h2>Smart replies, your voice.</h2><p>Editable demo or neutral local drafts. Read before you send.</p></div><span className="draft-only"><ShieldCheck size={13} /> DRAFT ONLY</span></div>
          <div className="reply-card"><div className="reply-head"><div className="reply-avatar">Y</div><div><b>{isDemo ? <>Reply in <span>#launch-room</span></> : 'Generic reply draft'}</b><small>{isDemo ? 'Drafted from the demo thread · never sent automatically' : 'Neutral starter only · not generated from inferred chat meaning'}</small></div><button className="icon-button" title="Reset reply" aria-label="Reset reply" onClick={() => changeTone(tone)}><RotateCcw size={15} /></button></div><div className="tone-tabs" role="group" aria-label="Reply tone">{['Professional', 'Friendly', 'Concise'].map(item => <button key={item} className={tone === item ? 'tone-active' : ''} onClick={() => changeTone(item)}>{item}</button>)}</div><textarea className="reply-editor" aria-label="Edit your smart reply" value={reply} onChange={e => setReply(e.target.value)} /><div className="reply-footer"><span><ShieldCheck size={13} /> Review before sending</span><button className="copy-button" onClick={handleCopy}>{copied ? <><Check size={14} /> Copied</> : <><Copy size={14} /> Copy reply</>}</button></div></div>
        </section>
        <footer className="studio-footer"><Logo /><span>Built to find the signal, not invent it.</span><button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>Back to top <ArrowUpRight size={13} /></button></footer>
      </div>
    </main>
    {sourceId !== null && <div className="modal-backdrop" role="presentation" onMouseDown={e => { if (e.target === e.currentTarget) setSourceId(null); }}><section className="source-modal" role="dialog" aria-modal="true" aria-labelledby="source-heading"><div className="modal-top"><span className="section-index">SOURCE MESSAGE</span><button aria-label="Close source" onClick={() => setSourceId(null)}><X size={17} /></button></div><h3 id="source-heading">{isDemo ? `Message #${sourceId}` : `Pasted line ${sourceId}`}</h3>{isDemo && activeSource ? <><div className="source-author"><span className="message-avatar">{activeSource.initials}</span><div><b>{activeSource.author}</b><small>{activeSource.time} · #{activeSource.channel}</small></div><SquareArrowOutUpRight size={14} /></div><blockquote>{activeSource.text}</blockquote><div className="source-note"><ShieldCheck size={14} /> Exact source from the fictional demo thread. This supports the finding shown.</div></> : <><div className="source-line"><span>LINE {sourceId}</span><p>{localLine || 'This line is not available in the current pasted text.'}</p></div><div className="source-note uncertain-note"><CircleHelp size={14} /> Exact pasted text only. The parser does not verify the interpretation.</div></>}<button className="modal-close-button" onClick={() => setSourceId(null)}>Close evidence</button></section></div>}
  </div>;
}

function NotFound() {
  return <div className="not-found"><Logo /><h1>This thread went quiet.</h1><p>The page you’re looking for isn’t here.</p><Link href="/" className="button-primary">Back to the beginning <ArrowRight size={15} /></Link></div>;
}
function App() {
  return <Switch><Route path="/" component={Landing} /><Route path="/studio" component={Studio} /><Route component={NotFound} /></Switch>;
}
export default App;
