import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { ArrowDown, ArrowRight, Asterisk, Star, Plus, Check } from 'lucide-react';

// ————— color story (split-complementary, muted) —————
// base: dusty ink-blue  #2E3A52 / #45587A
// split complements: faded terracotta #B05A3C , dirty ochre #C2932E
// paper: #EFE6D4 , deep ink: #1B2231

const INK = '#1B2231';
const BLUE = '#45587A';
const BLUE_DK = '#2E3A52';
const TERRA = '#B05A3C';
const OCHRE = '#C2932E';
const PAPER = '#EFE6D4';
const PAPER_DIM = '#E3D7BE';

function useCountdown() {
  const targetRef = useRef(null);
  if (!targetRef.current) {
    const t = new Date();
    t.setDate(t.getDate() + 47);
    t.setHours(19, 30, 0, 0);
    targetRef.current = t;
  }
  const calc = () => {
    const diff = Math.max(0, targetRef.current.getTime() - Date.now());
    return {
      d: Math.floor(diff / 86400000),
      h: Math.floor((diff / 3600000) % 24),
      m: Math.floor((diff / 60000) % 60),
      s: Math.floor((diff / 1000) % 60),
    };
  };
  const [t, setT] = useState(calc);
  useEffect(() => {
    const id = setInterval(() => setT(calc()), 1000);
    return () => clearInterval(id);
  }, []);
  return { ...t, target: targetRef.current };
}

const pad = (n) => String(n).padStart(2, '0');

const Marquee = ({ children, bg, color, reverse, border }) => (
  <div
    className="overflow-hidden whitespace-nowrap select-none"
    style={{ background: bg, color, borderTop: border, borderBottom: border }}
  >
    <div className={`marquee-track ${reverse ? 'marquee-rev' : ''} inline-flex items-center py-2.5`}>
      {[0, 1].map((i) => (
        <span key={i} className="inline-flex items-center">
          {Array.from({ length: 8 }).map((_, j) => (
            <span key={j} className="inline-flex items-center font-mono text-[11px] tracking-[0.28em] uppercase">
              <span className="px-5">{children}</span>
              <Asterisk size={12} strokeWidth={2.5} />
            </span>
          ))}
        </span>
      ))}
    </div>
  </div>
);

const Stamp = ({ children, rotate = -6, bg = TERRA, color = PAPER, className = '' }) => (
  <span
    className={`inline-block font-mono text-[10px] tracking-[0.22em] uppercase px-3 py-1.5 ${className}`}
    style={{ background: bg, color, transform: `rotate(${rotate}deg)`, boxShadow: `3px 3px 0 ${INK}` }}
  >
    {children}
  </span>
);

export default function App() {
  const { d, h, m, s, target } = useCountdown();
  const [rsvp, setRsvp] = useState(false);
  const [openFact, setOpenFact] = useState(0);

  const dateStr = new Intl.DateTimeFormat('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
  }).format(target);

  const facts = [
    { k: 'How long it took', v: '4 years, 2 months', note: 'We said two. We were wrong, and we’re okay with that now.' },
    { k: 'What it cost', v: '$48,212.07', note: 'Mostly savings, one small grant, and Dana’s tax refund.' },
    { k: 'Days of shooting', v: '23', note: 'Spread across 19 weekends and one very long Tuesday.' },
    { k: 'Takes of scene 14', v: '41', note: 'The dog would not sit. The dog is still in the movie.' },
    { k: 'People who helped', v: '117', note: 'Every single one is in the credits. Twice, if they brought food.' },
  ];

  const credits = [
    ['Written & Directed by', 'Marisol Vega'],
    ['Produced by', 'Dana Okafor'],
    ['Cinematography', 'Theo Brandt'],
    ['Edited by', 'June Castellanos'],
    ['Original Score', 'The Pell Street Quartet'],
    ['Sound', 'Ravi Menon'],
    ['Production Design', 'Holly Tran'],
    ['Starring', 'Carmen Reyes'],
    ['', 'Walter Igwe'],
    ['', 'Patty Lindqvist'],
    ['', 'and Biscuit (the dog)'],
    ['Catering', 'Marisol’s mom'],
  ];

  const units = [
    { n: pad(d), l: 'Days' },
    { n: pad(h), l: 'Hours' },
    { n: pad(m), l: 'Minutes' },
    { n: pad(s), l: 'Seconds' },
  ];

  return (
    <div style={{ background: PAPER, color: INK }} className="min-h-screen w-full overflow-x-hidden">
      <link
        href="https://fonts.googleapis.com/css2?family=Anton&family=Fraunces:ital,opsz,wght@0,9..144,300..900;1,9..144,300..900&family=Space+Mono:ital,wght@0,400;0,700;1,400&display=swap"
        rel="stylesheet"
      />
      <style
        dangerouslySetInnerHTML={{
          __html: `
        .font-display { font-family: 'Anton', sans-serif; }
        .font-serif-x { font-family: 'Fraunces', serif; }
        .font-mono { font-family: 'Space Mono', monospace; }
        .marquee-track { animation: marq 28s linear infinite; }
        .marquee-rev { animation-direction: reverse; }
        @keyframes marq { from { transform: translateX(0); } to { transform: translateX(-50%); } }
        @keyframes blink { 0%, 49% { opacity: 1; } 50%, 100% { opacity: 0.15; } }
        .blink { animation: blink 1s steps(1) infinite; }
        .outline-type {
          color: transparent;
          -webkit-text-stroke: 1.5px ${BLUE};
          opacity: 0.28;
        }
        .outline-type-terra {
          color: transparent;
          -webkit-text-stroke: 1.5px ${TERRA};
          opacity: 0.30;
        }
        .paper-noise::before {
          content: '';
          position: absolute; inset: 0;
          background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E");
          opacity: 0.07;
          pointer-events: none;
          z-index: 40;
          mix-blend-mode: multiply;
        }
        .dot-field {
          background-image: radial-gradient(${BLUE} 1.2px, transparent 1.2px);
          background-size: 14px 14px;
        }
        .dot-field-warm {
          background-image: radial-gradient(${TERRA} 1.2px, transparent 1.2px);
          background-size: 18px 18px;
        }
        .stripes {
          background-image: repeating-linear-gradient(-45deg, ${INK} 0 8px, transparent 8px 16px);
        }
        .stripes-warm {
          background-image: repeating-linear-gradient(-45deg, ${TERRA} 0 8px, transparent 8px 16px);
        }
        .perf {
          background-image: radial-gradient(circle at center, ${PAPER} 5px, transparent 5px);
          background-size: 24px 24px;
          background-position: center;
        }
        .num-shadow { text-shadow: 5px 5px 0 ${OCHRE}, 10px 10px 0 ${BLUE_DK}; }
        .hero-shadow { text-shadow: 4px 4px 0 ${PAPER}, 8px 8px 0 ${TERRA}; }
        ::selection { background: ${OCHRE}; color: ${INK}; }
        .fact-row { transition: background 0.25s ease, color 0.25s ease; }
        .fact-row:hover { background: ${INK}; color: ${PAPER}; }
        .scroll-thin::-webkit-scrollbar { height: 6px; }
        .scroll-thin::-webkit-scrollbar-thumb { background: ${BLUE}; }
      `,
        }}
      />

      <div className="relative paper-noise">
        {/* ——— top marquees ——— */}
        <Marquee bg={INK} color={PAPER}>
          World Premiere — One Night Only — Doors at 7:00 — Movie at 7:30, honestly
        </Marquee>
        <Marquee bg={TERRA} color={PAPER} reverse>
          Porchlight Pictures presents a film made by regular people on weekends
        </Marquee>

        {/* ——— header ——— */}
        <header className="flex items-stretch justify-between border-b-2" style={{ borderColor: INK }}>
          <div className="px-5 sm:px-8 py-4 flex items-center gap-3 border-r-2" style={{ borderColor: INK }}>
            <Star size={16} fill={OCHRE} stroke={INK} strokeWidth={1.5} />
            <span className="font-display text-xl tracking-wide uppercase">Porchlight Pictures</span>
          </div>
          <div className="hidden md:flex items-center px-6 font-mono text-[11px] tracking-[0.2em] uppercase gap-8" style={{ color: BLUE_DK }}>
            <span>Est. 2019</span>
            <span>Films № 003</span>
            <span className="flex items-center gap-2">
              <span className="blink inline-block w-2 h-2 rounded-full" style={{ background: TERRA }} />
              Counting down
            </span>
          </div>
          <div className="px-5 sm:px-8 flex items-center font-mono text-[11px] tracking-[0.2em] uppercase border-l-2" style={{ borderColor: INK, background: OCHRE }}>
            {dateStr}
          </div>
        </header>

        {/* ——— HERO : type only ——— */}
        <section className="relative border-b-2 overflow-hidden" style={{ borderColor: INK }}>
          {/* layered background type */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none select-none" aria-hidden>
            <div className="font-display outline-type leading-[0.82] uppercase whitespace-nowrap" style={{ fontSize: 'clamp(90px, 18vw, 260px)' }}>
              SOON SOON SOON SOON
            </div>
            <div className="font-display outline-type-terra leading-[0.82] uppercase whitespace-nowrap -ml-24" style={{ fontSize: 'clamp(90px, 18vw, 260px)' }}>
              SOON SOON SOON SOON
            </div>
            <div className="font-display outline-type leading-[0.82] uppercase whitespace-nowrap -ml-10" style={{ fontSize: 'clamp(90px, 18vw, 260px)' }}>
              SOON SOON SOON SOON
            </div>
            <div className="font-display outline-type-terra leading-[0.82] uppercase whitespace-nowrap -ml-32" style={{ fontSize: 'clamp(90px, 18vw, 260px)' }}>
              SOON SOON SOON SOON
            </div>
          </div>

          <div className="absolute right-0 top-0 bottom-0 w-10 sm:w-16 stripes-warm opacity-20" />
          <div className="absolute left-0 top-0 bottom-0 w-6 dot-field opacity-25" />

          <div className="relative max-w-7xl mx-auto px-6 sm:px-12 pt-16 pb-12 sm:pt-24 sm:pb-16">
            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="font-mono text-[11px] sm:text-xs tracking-[0.3em] uppercase mb-6 flex flex-wrap items-center gap-3"
              style={{ color: BLUE_DK }}
            >
              <Stamp rotate={-4}>It’s actually finished</Stamp>
              <Stamp rotate={3} bg={BLUE_DK}>No, really</Stamp>
              <span className="hidden sm:inline">/// our third feature, the one we kept mentioning</span>
            </motion.p>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="font-display uppercase leading-[0.85]"
              style={{ fontSize: 'clamp(64px, 14vw, 200px)' }}
            >
              <span className="block hero-shadow" style={{ color: BLUE_DK }}>Ordinary</span>
              <span className="block hero-shadow pl-[0.08em]" style={{ color: TERRA }}>
                Hours<span className="font-serif-x italic align-top" style={{ fontSize: '0.32em', color: INK, WebkitTextStroke: 0, textShadow: 'none' }}> (a movie)</span>
              </span>
            </motion.h1>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.8 }}
              className="mt-8 grid sm:grid-cols-12 gap-6 items-end"
            >
              <p className="sm:col-span-6 font-serif-x italic text-xl sm:text-2xl leading-snug" style={{ color: INK }}>
                A small film about a night-shift bus driver, his daughter’s science fair,
                and the forty-eight hours where nothing huge happens — except everything that matters.
              </p>
              <div className="sm:col-span-6 sm:text-right">
                <p className="font-mono text-[11px] tracking-[0.25em] uppercase mb-2" style={{ color: BLUE_DK }}>
                  Honest summary
                </p>
                <p className="font-mono text-sm leading-relaxed">
                  We made it on weekends. It’s 96 minutes. We cried at the rough cut,
                  but we’re biased. You can decide for yourself in—
                </p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* ——— COUNTDOWN ——— */}
        <section className="relative border-b-2" style={{ borderColor: INK, background: BLUE_DK }}>
          <div className="absolute inset-0 dot-field-warm opacity-[0.12] pointer-events-none" />
          <div className="h-3 perf" style={{ background: TERRA }} />
          <div className="relative max-w-7xl mx-auto px-6 sm:px-12 py-12 sm:py-16">
            <div className="flex flex-wrap items-baseline justify-between gap-4 mb-10">
              <h2 className="font-display uppercase text-3xl sm:text-5xl" style={{ color: PAPER }}>
                Until the lights go down
              </h2>
              <span className="font-mono text-[11px] tracking-[0.25em] uppercase" style={{ color: OCHRE }}>
                {dateStr} · 7:30 PM · The Bellmore Theater
              </span>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-px" style={{ background: PAPER }}>
              {units.map((u, i) => (
                <div key={u.l} className="relative px-6 py-8 sm:py-12 text-center" style={{ background: BLUE_DK }}>
                  <div
                    className="font-display num-shadow leading-none tabular-nums"
                    style={{ fontSize: 'clamp(56px, 9vw, 128px)', color: PAPER }}
                  >
                    {u.n}
                  </div>
                  <div className="mt-4 font-mono text-[11px] tracking-[0.35em] uppercase" style={{ color: OCHRE }}>
                    {u.l}
                  </div>
                  <Plus size={14} className="absolute top-3 left-3" color={TERRA} />
                  <Plus size={14} className="absolute bottom-3 right-3" color={TERRA} />
                  {i === 3 && (
                    <span className="absolute -top-3 right-4">
                      <Stamp rotate={6} bg={OCHRE} color={INK}>tick tick</Stamp>
                    </span>
                  )}
                </div>
              ))}
            </div>

            <p className="mt-8 font-serif-x italic text-lg sm:text-xl text-center" style={{ color: PAPER_DIM }}>
              That’s {d * 24 + h} hours. We know — we’ve been counting too.
            </p>
          </div>
          <div className="h-3 perf" style={{ background: TERRA }} />
        </section>

        <Marquee bg={OCHRE} color={INK} border={`2px solid ${INK}`}>
          One screen — 212 seats — Free popcorn while it lasts — Q&A after, if you stay
        </Marquee>

        {/* ——— THE HONEST PART ——— */}
        <section className="border-b-2" style={{ borderColor: INK }}>
          <div className="max-w-7xl mx-auto grid lg:grid-cols-12">
            <div className="lg:col-span-5 px-6 sm:px-12 py-12 sm:py-16 lg:border-r-2" style={{ borderColor: INK }}>
              <p className="font-mono text-[11px] tracking-[0.3em] uppercase mb-4" style={{ color: TERRA }}>
                01 / The honest part
              </p>
              <h3 className="font-display uppercase leading-[0.9] mb-8" style={{ fontSize: 'clamp(40px, 6vw, 84px)', color: BLUE_DK }}>
                We’re not<br />a studio.<br />
                <span style={{ color: TERRA }}>We’re six<br />people.</span>
              </h3>
              <div className="space-y-5 font-serif-x text-lg leading-relaxed max-w-md">
                <p>
                  Porchlight started in Dana’s garage with a folding table and a promise to make
                  films about people who look like our neighbors. <em>Ordinary Hours</em> is the
                  third one, and the first one we’re premiering in an actual theater.
                </p>
                <p>
                  No distributor yet. No famous names. Just a story we believed in enough to give
                  up four years of Saturdays. If that sounds like your kind of movie, the seat’s
                  already got your name on it.
                </p>
                <p className="font-mono text-xs tracking-[0.2em] uppercase pt-2" style={{ color: BLUE_DK }}>
                  — Marisol, Dana, Theo, June, Ravi & Holly
                </p>
              </div>
            </div>

            {/* facts ledger */}
            <div className="lg:col-span-7 px-6 sm:px-12 py-12 sm:py-16 relative" style={{ background: PAPER_DIM }}>
              <div className="absolute top-0 left-0 right-0 h-2 stripes opacity-20" />
              <p className="font-mono text-[11px] tracking-[0.3em] uppercase mb-6" style={{ color: BLUE_DK }}>
                02 / The receipts <span className="opacity-60">(click around)</span>
              </p>
              <div className="border-2" style={{ borderColor: INK }}>
                {facts.map((f, i) => (
                  <button
                    key={f.k}
                    onClick={() => setOpenFact(openFact === i ? -1 : i)}
                    className="fact-row w-full text-left px-5 sm:px-7 py-5 border-b-2 last:border-b-0 block"
                    style={{ borderColor: INK, background: openFact === i ? INK : 'transparent', color: openFact === i ? PAPER : INK }}
                  >
                    <div className="flex items-baseline justify-between gap-4 flex-wrap">
                      <span className="font-mono text-[11px] tracking-[0.25em] uppercase">{f.k}</span>
                      <span className="font-display text-2xl sm:text-4xl uppercase" style={{ color: openFact === i ? OCHRE : TERRA }}>
                        {f.v}
                      </span>
                    </div>
                    {openFact === i && (
                      <motion.p
                        initial={{ opacity: 0, y: -6 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="font-serif-x italic text-base mt-3"
                        style={{ color: PAPER_DIM }}
                      >
                        {f.note}
                      </motion.p>
                    )}
                  </button>
                ))}
              </div>
              <p className="mt-6 font-mono text-xs flex items-center gap-2" style={{ color: BLUE_DK }}>
                <ArrowDown size={14} /> Every dollar and every name is accounted for in the program. We typed it ourselves.
              </p>
            </div>
          </div>
        </section>

        {/* ——— CREDITS WALL ——— */}
        <section className="border-b-2 relative overflow-hidden" style={{ borderColor: INK, background: TERRA }}>
          <div className="absolute inset-0 dot-field opacity-10 pointer-events-none" />
          <div className="max-w-7xl mx-auto px-6 sm:px-12 py-12 sm:py-16 relative">
            <div className="flex flex-wrap items-end justify-between gap-4 mb-10">
              <h3 className="font-display uppercase leading-none" style={{ fontSize: 'clamp(40px, 7vw, 96px)', color: PAPER }}>
                Made by people<br />you’d like
              </h3>
              <Stamp rotate={4} bg={INK} color={OCHRE}>117 humans · 1 dog</Stamp>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-x-10 gap-y-3">
              {credits.map(([role, name], i) => (
                <div key={i} className="flex items-baseline justify-between gap-4 border-b py-2" style={{ borderColor: 'rgba(239,230,212,0.35)' }}>
                  <span className="font-mono text-[10px] tracking-[0.22em] uppercase" style={{ color: PAPER_DIM }}>
                    {role || '·'}
                  </span>
                  <span className="font-serif-x italic text-lg sm:text-xl text-right" style={{ color: PAPER }}>
                    {name}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ——— RSVP ——— */}
        <section className="relative border-b-2" style={{ borderColor: INK }}>
          <div className="max-w-7xl mx-auto px-6 sm:px-12 py-14 sm:py-20 text-center relative">
            <div className="absolute left-6 top-8 hidden md:block"><Stamp rotate={-8} bg={OCHRE} color={INK}>seats are free</Stamp></div>
            <div className="absolute right-6 bottom-8 hidden md:block"><Stamp rotate={5} bg={BLUE_DK}>bring whoever</Stamp></div>

            <p className="font-mono text-[11px] tracking-[0.3em] uppercase mb-5" style={{ color: TERRA }}>
              03 / Save your seat
            </p>
            <h3 className="font-display uppercase leading-[0.88] mb-8" style={{ fontSize: 'clamp(44px, 8vw, 110px)', color: BLUE_DK }}>
              Come see what<br />
              <span style={{ color: TERRA }}>we’ve been up to</span>
            </h3>

            <button
              onClick={() => setRsvp(!rsvp)}
              className="group inline-flex items-center gap-4 px-8 sm:px-12 py-5 font-display uppercase text-2xl sm:text-3xl tracking-wide transition-transform hover:-translate-y-1"
              style={{
                background: rsvp ? BLUE_DK : INK,
                color: rsvp ? OCHRE : PAPER,
                boxShadow: `6px 6px 0 ${rsvp ? TERRA : OCHRE}`,
              }}
            >
              {rsvp ? <Check size={28} strokeWidth={3} /> : <ArrowRight size={28} strokeWidth={3} className="transition-transform group-hover:translate-x-1" />}
              {rsvp ? 'You’re on the list' : 'Hold me a seat'}
            </button>
            <p className="mt-5 font-serif-x italic text-lg" style={{ color: BLUE_DK }}>
              {rsvp
                ? 'Great. We’ll hold you to it — front rows fill up with our parents, fair warning.'
                : 'No tickets, no fees. Just tell us you’re coming so we make enough popcorn.'}
            </p>
          </div>
        </section>

        {/* ——— footer marquees ——— */}
        <Marquee bg={BLUE_DK} color={PAPER}>
          {`Ordinary Hours — ${pad(d)} days ${pad(h)} hours ${pad(m)} minutes — The Bellmore Theater — ${dateStr}`}
        </Marquee>
        <footer className="flex flex-wrap items-center justify-between gap-3 px-6 sm:px-12 py-5 font-mono text-[10px] tracking-[0.25em] uppercase" style={{ background: INK, color: PAPER_DIM }}>
          <span>© Porchlight Pictures · Akron, Ohio</span>
          <span className="flex items-center gap-2">
            <Star size={11} fill={OCHRE} stroke="none" /> Film № 003 · 96 min · Not rated (it’s fine, bring grandma)
          </span>
          <span>Typed with care, no images harmed</span>
        </footer>
      </div>
    </div>
  );
}