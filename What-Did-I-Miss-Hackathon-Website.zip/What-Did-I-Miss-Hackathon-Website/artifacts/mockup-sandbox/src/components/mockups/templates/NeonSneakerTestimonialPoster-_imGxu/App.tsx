import { ArrowUpRight, Asterisk, Plus } from 'lucide-react';

const ACID = '#D7FF00';
const VOLT = '#FF4D00';

export default function App() {
  return (
    <div className="min-h-screen w-full bg-[#0A0A0A] text-[#EDEDED] overflow-x-hidden" style={{ fontFamily: "'Archivo', 'Helvetica Neue', sans-serif" }}>
      <link href="https://fonts.googleapis.com/css2?family=Archivo:ital,wght@0,400;0,500;0,600;0,700;0,800;0,900;1,700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet" />
      <style dangerouslySetInnerHTML={{ __html: `
        ::selection { background: ${ACID}; color: #0A0A0A; }
        .mono { font-family: 'Space Mono', monospace; }
        .grain {
          background-image: radial-gradient(rgba(255,255,255,0.035) 1px, transparent 1px);
          background-size: 3px 3px;
        }
        .stroke-text {
          -webkit-text-stroke: 1.5px ${ACID};
          color: transparent;
        }
        .cell { border: 1px solid #232323; margin: -0.5px; }
        body { background: #0A0A0A; }
        ::-webkit-scrollbar { width: 10px; background: #0A0A0A; }
        ::-webkit-scrollbar-thumb { background: #2a2a2a; border: 2px solid #0A0A0A; }
      `}} />

      <div className="grain min-h-screen flex flex-col">

        {/* ===== TOP STRIP ===== */}
        <div className="flex border-b border-[#232323]">
          <div className="px-4 py-2 border-r border-[#232323] flex items-center gap-2">
            <Asterisk size={16} style={{ color: ACID }} strokeWidth={2.5} />
            <span className="font-extrabold tracking-tight text-sm uppercase">FRACTAL FOOTWEAR</span>
          </div>
          <div className="px-4 py-2 border-r border-[#232323] mono text-[10px] uppercase tracking-widest text-[#7a7a7a] flex items-center">
            Drop 014 — Verified Buyer Transmission
          </div>
          <div className="px-4 py-2 border-r border-[#232323] mono text-[10px] flex items-center text-[#7a7a7a]">
            48.8566°N / 2.3522°E
          </div>
          <div className="ml-auto px-4 py-2 flex items-center mono text-[10px] uppercase" style={{ color: ACID }}>
            ● LIVE 10.04.25 — 09:00 CET
          </div>
        </div>

        {/* ===== HERO QUOTE ===== */}
        <div className="relative border-b border-[#232323]">
          {/* index column */}
          <div className="absolute left-0 top-0 bottom-0 w-10 border-r border-[#232323] flex flex-col justify-between py-3 items-center mono text-[9px] text-[#555]">
            <span>001</span>
            <span style={{ color: VOLT }}>QT</span>
            <span>014</span>
          </div>

          <div className="pl-14 pr-4 py-6 md:py-8">
            <div className="mono text-[10px] uppercase tracking-[0.3em] mb-4" style={{ color: ACID }}>
              “ Field report // Marcus Oyelaran — Lagos → Berlin
            </div>
            <h1
              className="font-black uppercase"
              style={{ fontSize: '14.5vw', lineHeight: 0.8, letterSpacing: '-0.04em' }}
            >
              I&nbsp;Wore<br />
              <span style={{ color: ACID }}>Them</span> to<br />
              <span className="stroke-text">Reinvent</span><br />
              Mys<span style={{ color: VOLT }}>elf.</span>
            </h1>
          </div>

          {/* rotated side label */}
          <div className="hidden md:block absolute right-2 top-1/2 -translate-y-1/2 mono text-[9px] tracking-[0.4em] uppercase text-[#555]" style={{ writingMode: 'vertical-rl' }}>
            Testimonial № 0147 — Unedited — Fractal Archive
          </div>
        </div>

        {/* ===== DENSE DATA GRID ===== */}
        <div className="grid grid-cols-2 md:grid-cols-12 flex-1">

          {/* Full quote body */}
          <div className="cell col-span-2 md:col-span-5 p-5 flex flex-col justify-between min-h-[260px]">
            <div className="mono text-[9px] uppercase tracking-widest text-[#555] mb-4 flex justify-between">
              <span>02 / Statement (Full)</span>
              <span style={{ color: ACID }}>VERIFIED ✓</span>
            </div>
            <p className="text-[15px] md:text-[17px] leading-snug font-medium text-[#D6D6D6]">
              “First day in the <span style={{ color: ACID }}>HELIX-90s</span> I caught my reflection in a U-Bahn window
              and didn't recognize the person standing there — in the best way. The midfoil cage looks like it was
              ripped off a satellite. Strangers stopped me three times before noon. These aren't sneakers, they're a
              <span className="italic font-bold"> permission slip to be louder.</span>”
            </p>
            <div className="mt-5 flex items-end justify-between">
              <div>
                <div className="font-extrabold uppercase tracking-tight text-lg leading-none">Marcus Oyelaran</div>
                <div className="mono text-[10px] text-[#7a7a7a] mt-1">Motion designer · Buyer since Drop 003</div>
              </div>
              <div className="text-right">
                <div className="font-black text-3xl leading-none" style={{ color: ACID }}>5.0</div>
                <div className="mono text-[9px] text-[#7a7a7a]">★★★★★</div>
              </div>
            </div>
          </div>

          {/* Product image */}
          <div className="cell col-span-2 md:col-span-4 relative min-h-[260px]">
            <img
              src="https://images.unsplash.com/photo-1600269452121-4f2416e55c28?w=900&h=700&fit=crop"
              alt="HELIX-90 sneaker"
              className="absolute inset-0 w-full h-full object-cover grayscale contrast-125"
            />
            <div className="absolute inset-0" style={{ background: 'linear-gradient(180deg, rgba(10,10,10,0.1) 0%, rgba(10,10,10,0.75) 100%)' }} />
            <div className="absolute top-3 left-3 mono text-[9px] uppercase tracking-widest px-2 py-1" style={{ background: ACID, color: '#0A0A0A' }}>
              Fig. 03 — HELIX-90 / Acid Static
            </div>
            <div className="absolute bottom-3 left-3 right-3 flex justify-between items-end">
              <div className="font-black uppercase text-2xl leading-none tracking-tight">Helix-90</div>
              <ArrowUpRight size={28} style={{ color: ACID }} strokeWidth={2.5} />
            </div>
          </div>

          {/* Spec stack */}
          <div className="col-span-2 md:col-span-3 grid grid-rows-4">
            {[
              ['Colorway', 'Acid Static / Carbon', ACID],
              ['SKU', 'FRC-HX90-014-AS', '#EDEDED'],
              ['Drop window', '10.04 — 10.06 / 2025', VOLT],
              ['Units pressed', '1,200 — No restock', '#EDEDED'],
            ].map(([label, value, color], i) => (
              <div key={i} className="cell p-4 flex flex-col justify-between">
                <span className="mono text-[9px] uppercase tracking-widest text-[#555]">{`0${i + 3} / ${label}`}</span>
                <span className="font-bold text-sm md:text-base uppercase tracking-tight" style={{ color }}>{value}</span>
              </div>
            ))}
          </div>

          {/* Bottom metric row */}
          {[
            ['Wear-test hours', '312', 'logged by 40 testers'],
            ['Repeat buyers', '87%', 'of Drop 013 holders'],
            ['Avg. rating', '4.9', 'across 1,043 reviews'],
            ['Resale delta', '+220%', '72h after Drop 013'],
          ].map(([label, big, sub], i) => (
            <div key={i} className="cell col-span-1 md:col-span-3 p-4 flex flex-col justify-between min-h-[120px]">
              <div className="flex justify-between items-start">
                <span className="mono text-[9px] uppercase tracking-widest text-[#555]">{label}</span>
                <Plus size={12} className="text-[#3a3a3a]" />
              </div>
              <div>
                <div className="font-black text-4xl md:text-5xl leading-none tracking-tighter" style={{ color: i === 3 ? VOLT : i === 1 ? ACID : '#EDEDED' }}>
                  {big}
                </div>
                <div className="mono text-[9px] text-[#7a7a7a] mt-1">{sub}</div>
              </div>
            </div>
          ))}
        </div>

        {/* ===== FOOTER STRIP ===== */}
        <div className="flex border-t border-[#232323] items-stretch">
          <div className="px-4 py-3 border-r border-[#232323] mono text-[10px] text-[#7a7a7a] flex items-center">
            FRACTAL.RUN/HELIX-90
          </div>
          <div className="hidden md:flex px-4 py-3 border-r border-[#232323] mono text-[10px] text-[#7a7a7a] items-center">
            DESIGNED IN BERLIN — BUILT FOR EVERYWHERE
          </div>
          <div className="ml-auto flex items-center gap-3 px-5 font-extrabold uppercase tracking-tight text-sm" style={{ background: ACID, color: '#0A0A0A' }}>
            Reserve your pair <ArrowUpRight size={18} strokeWidth={3} />
          </div>
        </div>
      </div>
    </div>
  );
}